const word = document.getElementById("secondWord");
word.style.color = "#b8b8b8";
word.style.fontWeight = "bold";
