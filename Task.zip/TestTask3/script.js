const word = document.getElementById("secondWord");
word.style.color = "#b8b8b8"; // Изменяем цвет на красный
word.style.fontWeight = "bold"; // Делаем жирным
