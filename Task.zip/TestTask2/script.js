document.querySelector(".scan-btn").addEventListener("click", function () {
  const barcodeField = document.getElementById("scannedBarcode");
  // Генерация штрихкода
  const randomBarcode = "A" + Math.floor(Math.random() * 1000000);
  barcodeField.textContent = randomBarcode;

  // Открытие/закрытие бургер-меню
  document.querySelector(".burger-btn").addEventListener("click", function (e) {
    e.stopPropagation();
    document.querySelector(".burger-content").classList.toggle("show");
  });

  // Закрытие меню при клике вне его
  document.addEventListener("click", function () {
    document.querySelector(".burger-content").classList.remove("show");
  });
});
